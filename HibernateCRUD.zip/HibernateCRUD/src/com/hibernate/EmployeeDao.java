package com.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class EmployeeDao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		Configuration con = new Configuration();
		con.configure("resources/hibernate.cfg.xml");
		SessionFactory sf = con.buildSessionFactory();
		
		
		
		System.out.println("Done");

	}

}
